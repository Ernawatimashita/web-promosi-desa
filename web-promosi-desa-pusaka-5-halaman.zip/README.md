# Website Promosi Desa Pusaka

Website terdiri dari 5 halaman:
1. index.html — Beranda
2. profil.html — Profil Desa
3. wisata.html — Wisata
4. produk.html — Produk UMKM
5. kontak.html — Kontak

Foto diletakkan di `assets/img/` dengan nama:
- desa.jpg
- kantor-desa.jpg
- jalan-desa.jpg
- sawah.jpg
- kegiatan.jpg
- wisata-1.jpg
- wisata-2.jpg
