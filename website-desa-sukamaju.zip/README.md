# Website Desa Sukamaju

Website promosi desa 5 halaman yang siap digunakan sebagai GitHub Pages.

## Halaman
- Beranda
- Profil Desa
- Wisata
- Produk & UMKM
- Kontak & Lokasi

## Cara upload
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder ini.
3. Masuk ke Settings → Pages.
4. Pilih branch `main` dan folder `/root`.
5. Simpan, lalu buka URL GitHub Pages.

Ganti nama desa, foto, alamat, nomor WhatsApp, dan akun media sosial sesuai data desa sebenarnya.
